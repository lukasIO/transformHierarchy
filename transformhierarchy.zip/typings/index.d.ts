/// <reference path="globals/requirejs/index.d.ts" />

